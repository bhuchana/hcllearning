package com.ckb.orderservice.common.dto;

public class TransactionResponse {
	
	private OrderDto orderDto;
	private double amount;
	private String transactionId;
	
	public TransactionResponse() {
		
	}
	public OrderDto getOrderDto() {
		return orderDto;
	}
	public void setOrderDto(OrderDto orderDto) {
		this.orderDto = orderDto;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

}
