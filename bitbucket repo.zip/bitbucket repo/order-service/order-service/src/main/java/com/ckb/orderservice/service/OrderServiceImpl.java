package com.ckb.orderservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.ckb.orderservice.common.dto.OrderDto;
import com.ckb.orderservice.common.dto.Payment;
import com.ckb.orderservice.common.dto.TransactionRequest;
import com.ckb.orderservice.common.dto.TransactionResponse;
import com.ckb.orderservice.entity.Order;
import com.ckb.orderservice.repository.OrderRepository;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	private OrderRepository orderRepository;
	
	@Autowired
	private RestTemplate restTemplate;

	@Override
	public TransactionResponse saveOrder(TransactionRequest transactionRequest) {
		
		
		OrderDto orderDto = transactionRequest.getOrderDto();
		Payment payment = transactionRequest.getPaymentDto();
		
		Order order = createOrder(orderDto);
		
		Order savedOrder = orderRepository.save(order);
		payment.setAmount(savedOrder.getPrice());
		payment.setOrderId(savedOrder.getId());
		restTemplate.postForObject("localhost:8082/paymentservice/payment", payment, Payment.class);
		
		return null;
	}

	private Order createOrder(OrderDto orderDto) {
		Order order=new Order();
		order.setName(orderDto.getName());
		order.setPrice(orderDto.getPrice());
		order.setQty(orderDto.getQty());
		return order;
	}
	
	

}
