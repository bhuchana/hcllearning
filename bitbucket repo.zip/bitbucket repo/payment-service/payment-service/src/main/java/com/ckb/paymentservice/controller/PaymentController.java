package com.ckb.paymentservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ckb.paymentservice.entity.Payment;
import com.ckb.paymentservice.service.PaymentService;

@RestController
@RequestMapping("/paymentservice")
public class PaymentController {
	
	@Autowired
	private PaymentService paymentService;
	
	@PostMapping("/payment")
	public Payment makePayment(@RequestBody Payment payment) {
		return paymentService.makePayment(payment);
	}

}
