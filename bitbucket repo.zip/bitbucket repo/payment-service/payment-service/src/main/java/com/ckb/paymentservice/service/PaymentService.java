package com.ckb.paymentservice.service;

import com.ckb.paymentservice.entity.Payment;

public interface PaymentService {

	public Payment makePayment(Payment payment);
}
